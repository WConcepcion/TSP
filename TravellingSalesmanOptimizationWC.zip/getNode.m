function nextCity = getNode(numCities, tabooList, cityWeight)

    probability = zeros(1, numCities);
        
    currentCity = tabooList(end);
    
    %remove connections to previous cities
    
    for tabooCity = 1:length(tabooList)
        cityWeight(tabooList(tabooCity),:) = 0;
    end

   
    %sum all the weights from current city
    probabilityDenominator = sum(cityWeight(:, currentCity));

    for eachCity = 1:numCities
       
       probabilityNumerator = cityWeight(eachCity, currentCity);
       
       probability(eachCity) = probabilityNumerator/probabilityDenominator;
       
       %random sample from each city using weighted probability
       
    end
    
    nextCity = randsample(numCities, 1, true, probability);
    
    
end

