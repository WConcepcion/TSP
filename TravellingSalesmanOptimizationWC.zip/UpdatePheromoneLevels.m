function pheromoneLevel = UpdatePheromoneLevels(pheromoneLevel,deltaPheromoneLevel,rho)

    pheromoneLevel = (1-rho)*pheromoneLevel + deltaPheromoneLevel;
    
    %introduce lower limit for Pheromone Level
    pheromoneLevel(pheromoneLevel < 1e-15) = 1e-15; 
    
end
