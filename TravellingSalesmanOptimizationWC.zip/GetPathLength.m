function pathLength = GetPathLength(path,cityLocation)

    pathLength = 0;
    
    for i = 1:length(cityLocation)
        if i == length(cityLocation)

            addedDistance = norm((cityLocation(path(1), :) - cityLocation(path(i), :)));
        else 

            addedDistance = norm((cityLocation(path(i+1), :) - cityLocation(path(i), :)));
        end
        
        pathLength = pathLength + addedDistance;
    end
end
