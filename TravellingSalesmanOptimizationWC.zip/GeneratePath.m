function path = GeneratePath(pheromoneLevel, visibility, alpha, beta)
    
    numCities = size(visibility, 1);
    
    %initialization
    tabooList = [];
    randStartNode = randi(numCities);
    tabooList(1) = randStartNode;
   
    %set city weights
    cityWeight = zeros(numCities);
    for i = 1:numCities
        for j = 1:numCities
            tau = pheromoneLevel(i, j);
            eta = visibility(i, j);
            cityWeight(i, j) = tau^alpha + eta^beta;
        end
    end
    
    
    
    for city = 1:numCities-length(tabooList)
        
        nextCity = getNode(numCities, tabooList, cityWeight);
        
        tabooList(city+1) = nextCity;
    end
        
    path = tabooList;
    
end

    
       
       
       
        
    
    
    
    
            