function pheromoneLevel = InitializePheromoneLevels(numberOfCities, tau0)
    tau = zeros(numberOfCities);
    
    for i = 1:numberOfCities
        for j = 1:numberOfCities
            if i ~= j
                tau(i, j) = tau0;
            end
        end
    end
    pheromoneLevel = tau;
end
