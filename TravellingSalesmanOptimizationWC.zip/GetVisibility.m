function visability = GetVisibility(cityLocation)

    visability = zeros(length(cityLocation));
    euclidianDistance = zeros(length(cityLocation));
    
    for i = 1:length(cityLocation)
        for j = 1:length(cityLocation)
            
            if i ~= j
                
            euclidianDistance(i, j) = norm(cityLocation(i, :) - cityLocation(j, :));

            visability(i, j) = 1/euclidianDistance(i, j);
            
            end
            
        end
    end
    
            