function deltaPheromoneLevel = ComputeDeltaPheromoneLevels(pathCollection,pathLengthCollection)

    numCities = size(pathCollection, 2);
    numAnts = size(pathCollection, 1);
    
    deltaPheromoneLevel = zeros(numCities);
    
    for k = 1:numAnts
        
        pathK = pathCollection(k, :);
        pathLengthK = pathLengthCollection(k);
        
        for city = 1:numCities
            i = pathK(city);
            if city == numCities
                j = pathK(city);
            else
                j = pathK(city+1);
            end
            
            deltaPheromoneLevel(i, j) = deltaPheromoneLevel(i, j) + 1/pathLengthK;
            
        end
        
        deltaPheromoneLevel(pathK(1), pathK(end)) = deltaPheromoneLevel(pathK(1), pathK(end)) +  1/pathLengthK;
        
    end
    
end

    
        
    